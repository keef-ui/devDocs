import { Component, Input } from '@angular/core';

@Component({
  selector: 'todolist',
  templateUrl: './ToDoList.component.html',
  styles: [`h1 { font-family: Lato; }`]
})
export class ToDoList {
  @Input() name: string;
 list= ["Get up in the morning", "Brush my teeth"];
   doneList= [0];
    _handleAddItem(newItem) {
    if (newItem.value === "") return;
    this.list.push(newItem.value);
    // console.log(newItem.value);
    newItem.value = "";
  }

  isChecked(item,index) {
    console.log(item,index);
   
    return (this.doneList.filter(function(val) {
            return val === index;
          }).length === 0 ||
            this.doneList.filter(function(val) {
              return val === index;
            }).length === undefined) ? false : true;
  }

  _handleUpdateDoneList(e,i) {
      console.log(e.target.checked);
      let checkIfInDoneList = this.doneList.filter(function(val) {
        return val === i;
      });
      if (checkIfInDoneList === undefined || checkIfInDoneList.length === 0) {
        // add to list
        this.doneList.push(i);
        e.target.checked = true;
      } else {
        //delete from list
        let i = this.doneList.indexOf(i);
        this.doneList.splice(i, 1);
        e.target.value = false;
      }
      console.log("donelist afterremove-->");
      console.log(this.doneList);
    }
}





